/**
 * Интерфейс, показывающий, что у текущего обЪекта можно узнать директорию
 */
public interface Directable {
    String getDirectory();
}
