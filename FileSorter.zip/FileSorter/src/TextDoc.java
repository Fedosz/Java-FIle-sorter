import java.io.File;
import java.io.FileReader;
import java.util.Objects;

public class TextDoc implements Directable {

    /**
     * @param fromRequirements - Если конструктор вызван из require текстового файла, то не добавляем его в список файлов
     */
    TextDoc(String directory, boolean fromRequirements) {
        this.directory = directory;

        readText();

        if (sorter != null) {
            if (!fromRequirements) {
                sorter.addDoc(this);
            }
        }

        findRequirements();
    }

    public String getDirectory() {
        return directory;
    }

    public String getText() {
        return text;
    }

    public TextDoc[] getRequirements() {
        return requirements;
    }

    /**
     * Назначение начальной директории
     * @param directory - директория
     */
    public static void setStartingDirectory(String directory) {
        inputDir = directory;
    }

    /**
     * Назначение текущего работающего сортировщика
     * @param fileSorter - сортировшик
     */
    public static void setSorter(FileSorter fileSorter) {
        sorter = fileSorter;
    }

    /**
     * Метод, находящий в тексте файла зависимости
     */
    private void findRequirements() {
        countRequirements();

        String[] lines = text.split("\n");
        int cur = 0;

        for (String line : lines) {
            String[] words = line.split(" ");

            // Ищем ключевое слово "require"
            if (Objects.equals(words[0], "require")) {
                char[] charWord = words[1].toCharArray();
                int countOfSymbols = 0;
                int i = 1;

                while (i < charWord.length && charWord[i] != '\'') {
                    countOfSymbols++;
                    i++;
                }

                char[] requirement = new char[countOfSymbols];

                System.arraycopy(charWord, 1, requirement, 0, requirement.length);
                String stringRequirement = inputDir + "//" + String.valueOf(requirement);

                // Флаг, показывающий существует ли необходимая нам директория в несортированном списке или еще нет
                boolean exists = false;
                TextDoc req = null;

                if (sorter.getSize() > 0) {
                    for (TextDoc doc : sorter.getDocs()) {
                        if (Objects.equals(doc.getDirectory(), stringRequirement)) {
                            req = doc;
                            exists = true;
                        }
                    }
                }

                if (!exists) {
                    req = new TextDoc(stringRequirement, true);
                }

                requirements[cur] = req;
                cur++;
            }
        }
    }

    /**
     * Метод, считающий количество зависимостей для задания размера массиву
     */
    private void countRequirements() {
        String[] lines = text.split("\n");
        int count = 0;

        for (String line : lines) {
            String[] words = line.split(" ");
            if (Objects.equals(words[0], "require")) {
                ++count;
            }
        }

        requirements = new TextDoc[count];
    }

    /**
     * Метод для чтения файла, ошибка говорит нам о том, что где-то неверный require
     */
    private void readText() {
        File cur = new File(directory);
        String words = "";

        try (FileReader reader = new FileReader(cur)) {
            int c;

            while ((c=reader.read()) != -1) {
                words += (char)c;
            }

        } catch (Exception e) {
            System.out.println("Wrong requirement");
            System.exit(0);
        }

        text = words;
    }

    private final String directory;
    private static String inputDir;
    private static FileSorter sorter;
    private String text;
    private TextDoc[] requirements;
}
