import java.util.ArrayList;
import java.util.Objects;

public class FileSorter implements Directable {
    /**
     * Класс, выполняющий различные проверки нашей директории
     */
    private class Checker {
        /**
         * Проверка на цикл
         * @param doc - текущий документ
         * @param i - счётчик длины зависимотси
         * @return - true, если есть цикл, false иначе
         * */
        private boolean isLoop(TextDoc doc, int i) {
             // Если счётчик переваливает за количество файлов в списке, это сигнализирует нам о цикле
             if (i >= docs.size()) {

                 System.out.println("Loop detected, fix it and restart the program");
                 System.out.println("Next files are looping:");
                 System.out.println(doc.getDirectory());

                 loopingDirectory = doc.getDirectory();

                 return true;
             }
             if (doc.getRequirements().length > 0) {
                 for (TextDoc document : doc.getRequirements()) {
                     // Если обнаружена зависимость, начинаем вывод зависимой цепочки
                     if (isLoop(document, (i + 1))) {

                         if (Objects.equals(doc.getDirectory(), loopingDirectory)) {
                             loopingDirectory = "";
                         }

                         if (!Objects.equals(loopingDirectory, doc.getDirectory()) && !Objects.equals(loopingDirectory, "")) {
                             System.out.println(doc.getDirectory());
                         }

                         return true;
                     }
                 }
             }
             return false;
         }

        /**
         * Провекра, что все файлы в require существуют в нашей директории
          * @return - true, если существуют, false иначе
         */
        private boolean haveMistakes() {
            for (TextDoc doc : docs) {
                if (doc.getRequirements().length > 0) {
                    for (TextDoc req : doc.getRequirements()) {
                        if (!isInArray(req)) {
                             System.out.println("Couldn't find " + req.getDirectory() + " from " + doc.getDirectory() +
                                     " in starting directory. Check files and try again.");
                             System.out.println("Program can contain other problems, we could notice you about them" +
                                     " only after you fix this first!");
                             return true;
                        }
                    }
                }
            }
            return false;
        }

        /**
         * Проверка, что файл уже добавлен в сортированный список
         * @param document - файл
         */
        private boolean isInSortedArray(TextDoc document) {
            for (TextDoc doc : sortedDocs) {
                if (Objects.equals(doc.getDirectory(), document.getDirectory())) {
                     return true;
                }
            }
            return false;
        }

        /**
         * Проверка что файл существует в директории
         * @param document - файл
         */
        private boolean isInArray(TextDoc document) {
            for (TextDoc doc : docs) {
                if (Objects.equals(doc.getDirectory(), document.getDirectory())) {
                    return true;
                }
            }
            return false;
        }
    }

    public FileSorter(String directory) {
        this.directory = directory;
        checker = new Checker();

        // Устанавливаем классу текстового файла текущего сортировщика и директорию
        TextDoc.setStartingDirectory(directory);
        TextDoc.setSorter(this);
    }

    public String getDirectory() {
        return directory;
    }

    /**
     * Метод, начинающий работу сортировщика
     */
    public void start() {
        Folder root = new Folder(directory);

        if (checker.haveMistakes()) {
            error = true;
            return;
        }

        for (TextDoc doc : docs) {
            if (checker.isLoop(doc, 0)) {
                error = true;
                return;
            }
        }

        for (TextDoc doc : docs) {
            addSortedDoc(doc);
        }
    }

    public void printSortedList() {
        if (!error) {
            for (TextDoc doc : sortedDocs) {
                System.out.println(doc.getDirectory());
            }
        } else {
            System.out.println("Error in input files");
        }
    }

    public void printFinalText() {
        if (!error) {
            for (TextDoc doc : sortedDocs) {
                System.out.println(doc.getText());
            }
        } else {
            System.out.println("Error in input files");
        }
    }
    public void addDoc(TextDoc doc) {
        docs.add(doc);
    }

    public int getSize() {
        return docs.size();
    }

    public ArrayList<TextDoc> getDocs() {
        return docs;
    }

    /**
     * Добавление элемента в сортированный массив. Перед добавлением самого элемента добавляются те, от которых он зависит
     * @param document - файл
     */
    private void addSortedDoc(TextDoc document) {
         if (!checker.isInSortedArray(document)) {
             if (document.getRequirements().length > 0) {
                 for (TextDoc req : document.getRequirements()) {
                     addSortedDoc(req);
                 }
             }
             sortedDocs.add(document);
         }
    }

    private final Checker checker;
    private final String directory;
    // Список всех файлов
    private final ArrayList<TextDoc> docs = new ArrayList<TextDoc>();
    private final ArrayList<TextDoc> sortedDocs = new ArrayList<TextDoc>();
    private String loopingDirectory;
    private Boolean error = false;
}
