import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter starting directory, example: D://javaHW");
        FileSorter sorter = null;
        // Флаг, указывающий на неправильно заданную директорию
        boolean wrongDirectory = true;
        Scanner scanner = new Scanner(System.in);

        while (wrongDirectory) {
            try {
                String startingDirectory = scanner.nextLine();
                sorter = new FileSorter(startingDirectory);
                sorter.start();
                wrongDirectory = false;
            } catch (Exception e) {
                System.out.println("Wrong directory, try again");
            }
        }

        System.out.println("Sorted list of docs with full directory:");
        sorter.printSortedList();

        System.out.println();

        System.out.println("Final text:");
        sorter.printFinalText();
    }
}