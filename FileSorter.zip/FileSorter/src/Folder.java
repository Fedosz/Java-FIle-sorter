import java.io.File;
import java.util.Objects;

public class Folder implements Directable {
    Folder(String directory) {
        this.directory = directory;

        getFoldersAndFiles();
    }

    public String getDirectory() {
        return directory;
    }

    public Folder[] getFolders() {
        return folders;
    }

    public TextDoc[] getTextDocs() {
        return textDocs;
    }

    /**
     * Метод организующий проход по файлам
     */
    private void getFoldersAndFiles() {
        File dir = new File(directory);
        int countOfFolders = 0;
        int countOfTextFiles = 0;

        // Считаем количество папок и файлов
        for (File item : Objects.requireNonNull(dir.listFiles())) {
            if (item.isDirectory()) {
                countOfFolders++;
            } else {
                countOfTextFiles++;
            }
        }

        folders = new Folder[countOfFolders];
        textDocs = new TextDoc[countOfTextFiles];
        int i = 0;
        int j = 0;

        // Добавляем файлы и папки в поля класса
        for (File item : Objects.requireNonNull(dir.listFiles())) {
            if (item.isDirectory()) {
                Folder fold = new Folder(directory + "//" + item.getName());
                folders[i] = fold;
                i++;
            } else {
                TextDoc file = new TextDoc(directory + "//" + item.getName(), false);
                textDocs[j] = file;
                j++;
            }
        }
    }

    private final String directory;
    private Folder[] folders;
    private TextDoc[] textDocs;
}
